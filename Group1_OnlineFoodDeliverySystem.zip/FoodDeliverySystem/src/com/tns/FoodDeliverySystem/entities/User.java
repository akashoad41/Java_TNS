package com.tns.FoodDeliverySystem.entities;

public class User {
	
	    protected int userId;
	    protected String name;
	    protected String email;
	    protected String password;

	    public User(int userId, String name, String email, String password) {
	        this.userId = userId;
	        this.name = name;
	        this.email = email;
	        this.password = password;
	    }

	    public int getUserId() {
	        return userId;
	    }

	    public String getName() {
	        return name;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public String getPassword() {
	        return password;
	    }
	}


