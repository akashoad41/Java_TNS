let player1 = "Player 1";
let player2 = "Player 2";

function editNames() {
    let newPlayer1 = prompt("Enter Player 1 Name:");
    let newPlayer2 = prompt("Enter Player 2 Name:");

    if (newPlayer1) player1 = newPlayer1;
    if (newPlayer2) player2 = newPlayer2;

    document.getElementById("player1Name").innerText = player1;
    document.getElementById("player2Name").innerText = player2;
}

function rollDice() {
    let roll1 = Math.floor(Math.random() * 6) + 1;
    let roll2 = Math.floor(Math.random() * 6) + 1;

    document.getElementById("dice1").src = `dice${roll1}.png`;
    document.getElementById("dice2").src = `dice${roll2}.png`;

    let result = document.getElementById("game-result");

    if (roll1 === roll2) {
        result.innerText = "It's a tie! 🎲 Roll Again!";
    } else if (roll1 === 6 || roll2 === 6) {
        result.innerText = "🎉 Extra Turn for Six!";
    } else {
        result.innerText = roll1 > roll2 ? `${player1} Wins! 🏆` : `${player2} Wins! 🏆`;
    }
}
